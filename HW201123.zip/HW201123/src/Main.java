import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1.1 Напишите программу, в которой объявите переменные всех примитивных типов.
        // Значение для каждой переменной сгенерируйте с помощью класса Random.
        // При необходимости используйте приведение типов. Полученные значения выведите в консоль.

        //2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
        // При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет.
        // Полученное значение выведите в консоль.

        //1
        Random rnd = new Random();
        byte b = (byte) rnd.nextInt();
        short s = (short) rnd.nextInt();
        char c = (char) rnd.nextInt();
        int i = rnd.nextInt();
        long l = rnd.nextLong();
        float f = rnd.nextFloat();
        double d = rnd.nextDouble();

        System.out.println("byte = " + b);
        System.out.println("short = " + s);
        System.out.println("char = " + c);
        System.out.println("int = " + i);
        System.out.println("long = " + l);
        System.out.println("float = " + f);
        System.out.println("double = " + d);

        //2
        String stroka = String.valueOf(f);
        System.out.println("число = " + f);
        System.out.println("текст = " + stroka + 10);

        //№2
        //Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать сообщение: «Уважаемый, [Имя]!
        // В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.». В сообщении [Имя],
        // [Возраст] и [Вес] должны принять введённые значения.

        Scanner scr = new Scanner(System.in);

        System.out.println("Name");
        String name = scr.nextLine();

        System.out.println("age");
        int age = scr.nextInt();

        System.out.println("ves");
        double ves = scr.nextDouble();

        System.out.println("«Уважаемый, " + name + " ! В свои " + age + " лет Вы для нас дороги, как "+
                 ves + " килограмм золота.»");

        //№3 Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        // разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
        // Результат вычисления выведите в консоль.

        System.out.println("Первое число");
        int firstNumber = scr.nextInt();

        System.out.println("Второе число");
        int secondNumber = scr.nextInt();

        System.out.println("сложение = "+(firstNumber+secondNumber));
        System.out.println("вычитание = "+(firstNumber-secondNumber));
        System.out.println("умножение = "+(firstNumber*secondNumber));
        System.out.println("деление  =  "+(firstNumber/secondNumber));


    }
}